<?php

use JetBrains\PhpStorm\Internal\LanguageLevelTypeAware;
use JetBrains\PhpStorm\Pure;

/**
 * The ReflectionReference class provides information about a reference.
 *
 * Note: Unlike the description in the documentation, the class itself is not final.
 *
 * @link https://www.php.net/manual/en/class.reflectionreference.php
 * @since 7.4
 */
final class ReflectionReference
{
    /**
     * ReflectionReference cannot be created explicitly.
     * @link https://php.net/manual/en/reflectionreference.construct.php
     */
    private function __construct() {}

    /**
     * Returns ReflectionReference if array element is a reference, {@see null} otherwise
     *
     * @link https://php.net/manual/en/reflectionreference.fromarrayelement.php
     * @param array $array The array which contains the potential reference.
     * @param int|string $key The key; either an integer or a string.
     * @return ReflectionReference|null Returns a ReflectionReference instance if $array[$key] is a
     * reference, or null otherwise.
     * @throws \TypeError If array is not an array, or key is not an integer or string, a TypeError
     * is thrown.
     * @throws \ReflectionException If $array[$key] does not exist, a ReflectionException is thrown.
     */
    public static function fromArrayElement(
        array $array,
        #[LanguageLevelTypeAware(['8.0' => 'string|int'], default: '')] $key
    ): ?ReflectionReference {}

    /**
     * Returns unique identifier for the reference. The return value format is unspecified
     *
     * @link https://php.net/manual/en/reflectionreference.getid.php
     * @return int|string Returns an integer or string of unspecified format.
     */
    #[Pure]
    public function getId(): string {}

    /**
     * ReflectionReference cannot be cloned
     *
     * @return void
     */
    private function __clone(): void {}
}
