<?php

use JetBrains\PhpStorm\Internal\LanguageLevelTypeAware;
use JetBrains\PhpStorm\Pure;

/**
 * @since 8.0
 */
class ReflectionUnionType extends ReflectionType
{
    /**
     * Get list of types of union type
     *
     * @link https://php.net/manual/en/reflectionuniontype.gettypes.php
     * @return ReflectionNamedType[]|ReflectionIntersectionType[] An array of ReflectionType
     * objects.
     */
    #[Pure]
    #[LanguageLevelTypeAware(
        [
            '8.2' => 'ReflectionNamedType[]|ReflectionIntersectionType[]'
        ],
        default: 'ReflectionNamedType[]'
    )]
    public function getTypes(): array {}
}
